<?php

namespace App\Http\Livewire;

use Livewire\Component;

//for image upload
use Livewire\WithFileUploads;


class Post extends Component
{
    
    //for image upload
    use WithFileUploads;
    public $image;

    public function upload()
    {
        $this->validate([
            'image' => 'image|max:1024', // Validate image file (max 1MB)
        ]);

        $this->image->store('images', 'public'); // Store the image in 'storage/app/public/images'

        session()->flash('message', 'Image uploaded successfully!');
    }



    //show view file livewire
    public function render()
    {
        return view('livewire.post');
    }
}
