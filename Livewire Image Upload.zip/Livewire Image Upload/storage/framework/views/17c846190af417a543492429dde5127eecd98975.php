<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Post View Page</title>

	<?php echo \Livewire\Livewire::styles(); ?>

</head>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post')->html();
} elseif ($_instance->childHasBeenRendered('ieFhQoD')) {
    $componentId = $_instance->getRenderedChildComponentId('ieFhQoD');
    $componentTag = $_instance->getRenderedChildComponentTagName('ieFhQoD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ieFhQoD');
} else {
    $response = \Livewire\Livewire::mount('post');
    $html = $response->html();
    $_instance->logRenderedChild('ieFhQoD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

	<?php echo \Livewire\Livewire::scripts(); ?>

<body>
	
</body>
</html><?php /**PATH D:\wamp64\www\LivewireLaraEight\resources\views/post/index.blade.php ENDPATH**/ ?>