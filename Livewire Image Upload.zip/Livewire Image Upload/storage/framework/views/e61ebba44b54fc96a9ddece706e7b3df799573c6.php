
<div style="text-align: center;">
    <h1>Livewire View Page for Image uploading</h1><br><br>

    <div>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <form wire:submit.prevent="upload">
            <input type="file" wire:model="image">
            
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <br><br>
            <button type="submit">Submit</button>
        </form>
    </div>

</div>
<?php /**PATH D:\wamp64\www\LivewireLaraEight\resources\views/livewire/post.blade.php ENDPATH**/ ?>