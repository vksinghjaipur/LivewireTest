
<div style="text-align: center;">
    <h1>Livewire View Page for Image uploading</h1><br><br>

    <div>
        @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session('message') }}
            </div>
        @endif

        <form wire:submit.prevent="upload">
            <input type="file" wire:model="image">
            
            @error('image') <span class="error">{{ $message }}</span> @enderror

            <br><br>
            <button type="submit">Submit</button>
        </form>
    </div>

</div>
