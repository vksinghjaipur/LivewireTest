

<div>

	@if (session()->has('message'))
            <div class="alert alert-success">
                {{ session('message') }}
            </div>
        @endif
	
	<h1>File Upload</h1>

	<form wire:submit.prevent="save">
		<input type="file" wire:model="photo">

        <br><br>
		<button type="submit">Submit</button>
	</form>
</div>