<div style="text-align: center;">
    <h1>Hello Livewire World!</h1>


    <h2>Counter Application</h2>

    <button wire:click="increament">+</button>
    <h1>{{$count}}</h1>
    <button wire:click="decreament">-</button>

</div>




