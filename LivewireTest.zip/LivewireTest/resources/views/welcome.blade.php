<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel Welcome page</title>

        @livewireStyles  
    </head>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">

        
        
          <!-- Ye Counter File h blade show ek hi h -->
        <livewire:counter/>

        

        <!-- Ye Alag File h File Upload -->
        <livewire:file-upload/>


        @livewireScripts
    </body>
</html>





