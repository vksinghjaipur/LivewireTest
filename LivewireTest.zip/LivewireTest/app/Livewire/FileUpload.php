<?php

namespace App\Livewire;

use Livewire\Component;

//V use trait here
use Livewire\WithFileUploads;

class FileUpload extends Component
{
    
   use WithFileUploads;
   public $photo;
   
   
   public function save()
   {
     $this->validate([
            'photo' => 'image|max:1024', // 1MB Max
      ]);

      $this->photo->store('photos');
      //$filename = $this->photo->getClientOriginalName();
      //$this->photo->storeAs('photos', $filename);

      session()->flash('message', 'Photo successfully uploaded.');
   }


   public function render()
   {
      return view('livewire.file-upload');
   }

   



   // public function save()
   // {
   //    $this->photo->store('photos');
   // }

}



